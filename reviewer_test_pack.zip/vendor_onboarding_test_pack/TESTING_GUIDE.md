# Vendor Onboarding demo: testing guide

**App:** use the link you were given.

Every company, identifier and document in this pack is **synthetic**. Each PDF carries a
"SYNTHETIC TEST DOCUMENT" watermark.

## How to run one scenario

1. Open the app, tab **New Submission & Live Run**.
2. Copy the vendor's eight values below into the form.
3. Upload the three files listed for that vendor into the matching slots.
4. Click **Submit for review** and watch the seven stages run (each document is read by
   Gemini, so a run can take up to a minute).
5. Compare the decision with **Expected** below, then check the rule evidence, extracted
   JSON and drafted email.
6. Click **Start a new submission** before the next vendor.

The **Operations Dashboard** tab shows the history, stage logs and the reference tables
(one pre-approved vendor and one blocklisted entity, used by Vendors 07 and 08).

**Re-running Vendor 01 or 02?** Approved vendors are remembered, so a second approval of
the same company is correctly **REJECTED** as `DUPLICATE_VENDOR`. To approve it again,
open Operations Dashboard → **Demo controls** → **Reset demo approvals**.

## Scenarios at a glance

| # | Vendor | What it tests | Expected | Failing rule |
|---|---|---|---|---|
| 01 | Kovai Precision Components Pvt Ltd | Happy path: consistent form and digital GST, PAN and bank PDFs | **APPROVED** | — |
| 02 | Deccan Agro Exports Ltd | Consistent submission; all three documents are scanned image-only PDFs | **APPROVED** | — |
| 03 | Apex Cloud Solutions Pvt Ltd | Bank proof account holder is an unrelated individual (Rohan Sharma) | **REJECTED** | `BANK_BENEFICIARY_MISMATCH` |
| 04 | Vanguard Logistics India Pvt Ltd | Form legal name differs from GST/PAN legal entity; bank holder and GST trade name match the documented entity | **PENDING** | `LEGAL_NAME_MISMATCH` |
| 05 | Narmada Polymers LLP | GSTIN (valid checksum) embeds PAN AABFN9999K; form and PAN document show AABFN4321K | **REJECTED** | `PAN_GSTIN_MISMATCH` |
| 06 | Zenith Packaging Industries | Electricity bill in GST certificate slot | **PENDING** | `WRONG_DOCUMENT_TYPE` |
| 07 | Meridian Tech Services Pvt Ltd | PAN, GSTIN, account and IFSC equal a pre-seeded approved vendor | **REJECTED** | `DUPLICATE_VENDOR` |
| 08 | Orion Global Traders | PAN exactly matches a seeded internal blocklist entry | **REJECTED** | `BLOCKLIST_MATCH` |

## Form values and uploads

### Vendor 01: Kovai Precision Components Pvt Ltd

Folder: `vendor_01_kovai_precision/`

| Field | Value |
|---|---|
| Legal name | Kovai Precision Components Pvt Ltd |
| Trade name (optional) | Kovai Precision |
| Contact email | accounts@kovai-precision.example |
| Registered address | Plot 14, SIDCO Industrial Estate, Kurichi, Coimbatore, Tamil Nadu 641021, India |
| PAN | AAKCK4821M |
| GSTIN | 33AAKCK4821M1ZB |
| Bank account number | 50200048213377 |
| IFSC | CDBL0001042 |

| Upload slot | File |
|---|---|
| GST registration certificate | `gst_certificate.pdf` |
| PAN document | `pan_card.pdf` |
| Bank account confirmation | `bank_proof.pdf` |

**Expected:** **APPROVED**

### Vendor 02: Deccan Agro Exports Ltd

Folder: `vendor_02_deccan_agro/`

| Field | Value |
|---|---|
| Legal name | Deccan Agro Exports Ltd |
| Trade name (optional) | Deccan Agro |
| Contact email | finance@deccan-agro.example |
| Registered address | Survey No. 112, Shamshabad Road, Rajendranagar, Hyderabad, Telangana 500030, India |
| PAN | AADCD5532Q |
| GSTIN | 36AADCD5532Q1Z9 |
| Bank account number | 918020061734552 |
| IFSC | IVDB0003117 |

| Upload slot | File |
|---|---|
| GST registration certificate | `gst_certificate.pdf` |
| PAN document | `pan_card.pdf` |
| Bank account confirmation | `bank_proof.pdf` |

**Expected:** **APPROVED**

### Vendor 03: Apex Cloud Solutions Pvt Ltd

Folder: `vendor_03_apex_cloud/`

| Field | Value |
|---|---|
| Legal name | Apex Cloud Solutions Pvt Ltd |
| Trade name (optional) | Apex Cloud |
| Contact email | ap@apex-cloud.example |
| Registered address | 4th Floor, 27 Outer Ring Road, Bellandur, Bengaluru, Karnataka 560103, India |
| PAN | AAFCA7314R |
| GSTIN | 29AAFCA7314R1Z3 |
| Bank account number | 39871204556 |
| IFSC | SFDB0000729 |

| Upload slot | File |
|---|---|
| GST registration certificate | `gst_certificate.pdf` |
| PAN document | `pan_card.pdf` |
| Bank account confirmation | `bank_proof.pdf` |

**Expected:** **REJECTED** · `BANK_BENEFICIARY_MISMATCH`

### Vendor 04: Vanguard Logistics India Pvt Ltd

Folder: `vendor_04_vanguard_logistics/`

| Field | Value |
|---|---|
| Legal name | Vanguard Logistics India Pvt Ltd |
| Trade name (optional) | Vanguard Logistics |
| Contact email | accounts@vanguard-logistics.example |
| Registered address | Unit 7, Bhiwandi Logistics Park, Thane, Maharashtra 421302, India |
| PAN | AAHCV6620L |
| GSTIN | 27AAHCV6620L1ZX |
| Bank account number | 60331987204418 |
| IFSC | CDBL0004410 |

| Upload slot | File |
|---|---|
| GST registration certificate | `gst_certificate.pdf` |
| PAN document | `pan_card.pdf` |
| Bank account confirmation | `bank_proof.pdf` |

**Expected:** **PENDING** · `LEGAL_NAME_MISMATCH`

### Vendor 05: Narmada Polymers LLP

Folder: `vendor_05_narmada_polymers/`

| Field | Value |
|---|---|
| Legal name | Narmada Polymers LLP |
| Trade name (optional) | Narmada Polymers |
| Contact email | accounts@narmada-polymers.example |
| Registered address | Plot 88, GIDC Estate, Makarpura, Vadodara, Gujarat 390010, India |
| PAN | AABFN4321K |
| GSTIN | 24AABFN9999K1ZH |
| Bank account number | 77120045893301 |
| IFSC | IVDB0002408 |

| Upload slot | File |
|---|---|
| GST registration certificate | `gst_certificate.pdf` |
| PAN document | `pan_card.pdf` |
| Bank account confirmation | `bank_proof.pdf` |

**Expected:** **REJECTED** · `PAN_GSTIN_MISMATCH`

### Vendor 06: Zenith Packaging Industries

Folder: `vendor_06_zenith_packaging/`

| Field | Value |
|---|---|
| Legal name | Zenith Packaging Industries |
| Trade name (optional) | Zenith Packaging |
| Contact email | accounts@zenith-packaging.example |
| Registered address | B-42, Okhla Industrial Area Phase II, New Delhi, Delhi 110020, India |
| PAN | AAGFZ2045H |
| GSTIN | 07AAGFZ2045H1Z4 |
| Bank account number | 41290033871652 |
| IFSC | SFDB0001175 |

| Upload slot | File |
|---|---|
| GST registration certificate | `Electricity_Utility_Bill.pdf`  ⚠ not a GST certificate, on purpose |
| PAN document | `pan_card.pdf` |
| Bank account confirmation | `bank_proof.pdf` |

**Expected:** **PENDING** · `WRONG_DOCUMENT_TYPE`

### Vendor 07: Meridian Tech Services Pvt Ltd

Folder: `vendor_07_meridian_tech/`

| Field | Value |
|---|---|
| Legal name | Meridian Tech Services Pvt Ltd |
| Trade name (optional) | Meridian Tech |
| Contact email | finance@meridian-tech.example |
| Registered address | Office 502, Baner Business Bay, Baner, Pune, Maharashtra 411045, India |
| PAN | AAMCM3398E |
| GSTIN | 27AAMCM3398E1Z3 |
| Bank account number | 50100392847716 |
| IFSC | CDBL0002216 |

| Upload slot | File |
|---|---|
| GST registration certificate | `gst_certificate.pdf` |
| PAN document | `pan_card.pdf` |
| Bank account confirmation | `bank_proof.pdf` |

**Expected:** **REJECTED** · `DUPLICATE_VENDOR`

### Vendor 08: Orion Global Traders

Folder: `vendor_08_orion_global/`

| Field | Value |
|---|---|
| Legal name | Orion Global Traders |
| Trade name (optional) | Orion Global |
| Contact email | accounts@orion-global.example |
| Registered address | Door 33/1180, Market Road, Ernakulam, Kochi, Kerala 682011, India |
| PAN | AAKFO8812D |
| GSTIN | 32AAKFO8812D1ZF |
| Bank account number | 20984411730059 |
| IFSC | IVDB0005531 |

| Upload slot | File |
|---|---|
| GST registration certificate | `gst_certificate.pdf` |
| PAN document | `pan_card.pdf` |
| Bank account confirmation | `bank_proof.pdf` |

**Expected:** **REJECTED** · `BLOCKLIST_MATCH`
